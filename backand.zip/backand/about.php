<?php include "left-sidebar.php" ?>
<div class="col-lg-9 col-md-12 col-sm-12">
    <div class="container">
        <div class="custom_navbar">
            <a href="" class="burger-btn" id="open"><button class="btn btn-primary"><i
                        class="fas fa-bars"></i></button></a>
        </div>
        <div class="row my-5">
            <div class="col-xl-6 col-md-12 col-sm-12">
                <div class="about_image">
                    <img src="images/h1-single-img-2.png" alt="">
                </div>
            </div>
            <div class="col-xl-6 col-md-12 col-sm-12">
                <h2>About Us</h2>
                <p>
                    Lorem, ipsum dolor sit amet consectetur
                    adipisicing elit. Non accusamus, eaque odio cum
                    voluptatibus id excepturi est, culpa minima
                    alias dolor, tempora hic quia explicabo fuga
                    corrupti voluptas doloremque praesentium?
                    Lorem, ipsum dolor sit amet consectetur
                    adipisicing elit. Non accusamus, eaque odio cum
                    voluptatibus id excepturi est, culpa minima
                    alias dolor, tempora hic quia explicabo fuga
                    corrupti voluptas doloremque praesentium?
                    Lorem, ipsum dolor sit amet consectetur
                    adipisicing elit. Non accusamus, eaque odio cum
                    voluptatibus id excepturi est, culpa minima
                    alias dolor, tempora hic quia explicabo fuga
                    corrupti voluptas doloremque praesentium?
                    Lorem, ipsum dolor sit amet consectetur
                    adipisicing elit. Non accusamus, eaque odio cum
                    voluptatibus id excepturi est, culpa minima
                    alias dolor, tempora hic quia explicabo fuga
                    corrupti voluptas doloremque praesentium?
                    Lorem, ipsum dolor sit amet consectetur
                    adipisicing elit. Non accusamus, eaque odio cum
                    voluptatibus id excepturi est, culpa minima
                    alias dolor, tempora hic quia explicabo fuga
                    corrupti voluptas doloremque praesentium?
                    Lorem, ipsum dolor sit amet consectetur
                    adipisicing elit. Non accusamus, eaque odio cum
                    voluptatibus id excepturi est, culpa minima
                    alias dolor, tempora hic quia explicabo fuga
                    corrupti voluptas doloremque praesentium?
                </p>
            </div>
        </div>
    </div>
</div>
</div>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/action.js"></script>
</body>

</html>