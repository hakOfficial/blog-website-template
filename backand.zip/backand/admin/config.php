<?php
// <!-- create database connection -->

$hostname = "localhost";
$username = "root";
$password = "";
$database = "tutweb";


$conn = mysqli_connect($hostname, $username, $password, $database);