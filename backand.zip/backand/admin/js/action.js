// alert("start coding for insert the data")

// insert data to database


$(document).ready(function () {
    $("#add_Category").on("click", function () {
        // console.log("can work");

        var cat_name = $("#cat_name").val();

        if (cat_name === "") {
            alert("please fill the field");
        } else {
            $.ajax({
                type: "POST",
                url: "add-category.php",
                data: {
                    cat_name
                }, // js es6 rule if in object name is same write that name once ok
                success: function (data) {
                    console.log(data);
                    if (data == 1) {
                        $("#modelId").model("hide");
                        console.log("insert successfully");
                    } else if (data == 2) {
                        console.log("category name already exist");
                    } else {
                        console.log("some thing woring");
                    }
                }
            });
        }
    })
});