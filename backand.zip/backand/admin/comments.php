<?php
include "header.php";
?>
<div id="layoutSidenav_content">
    <main>
        <h1>this is comments </h1>
    </main>

    <?php

    include "footer.php";

    ?>