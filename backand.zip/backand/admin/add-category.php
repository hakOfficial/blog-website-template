<?php

include "config.php";


if (isset($_POST["cat_name"])) {
    $cat_name = $_POST["cat_name"];

    $select_sql = "SELECT * FROM categories WHERE category_name = '{$cat_name}'";
    $run_select_sql = mysqli_query($conn, $select_sql);
    if (mysqli_num_rows($run_select_sql) > 0) {
        echo 2;
    } else {
        $sql = "INSERT INTO categories (category_name) VALUES ('{$cat_name}')";
        if (mysqli_query($conn, $sql)) {
            echo 1;
        } else {
            echo 0;
        }
    }
}