<?php include "header.php" ?>

<div id="layoutSidenav_content">
    <main>
        <!-- to create model  -->

        <div class="container my-5">
            <div class="card">
                <div class="card-header">
                    <span> category ( 4 ) </span>
                    <span> <button type="button" class="btn btn-primary float-right" data-toggle="modal"
                            data-target="#modelId">
                            Add Category
                        </button></span>
                </div>
            </div>
        </div>

        <!-- Button trigger modal -->


        <!-- Add category Modal -->
        <div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Student</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="">
                            <div class="form-group">
                                <label for="">Enter Category Name</label>
                                <input type="text" name="cat_name" id="cat_name" class="form-control">
                            </div>
                            <div class="form-group">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="button" id="add_Category" class="btn btn-primary">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include "footer.php"  ?>