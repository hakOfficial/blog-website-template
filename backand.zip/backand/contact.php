<?php include "left-sidebar.php" ?>
<div class="col-lg-9 col-md-12 col-sm-12">
    <div class="container">
        <div class="custom_navbar">
            <a href="" class="burger-btn" id="open"><button class="btn btn-primary"><i
                        class="fas fa-bars"></i></button></a>
        </div>
        <div class="row mt-5">
            <div class="col-xl-6 col-md-8 col-sm-12 offset-md-2">
                <h1>Contact Form</h1>
                <form action="">
                    <div class="form-group">
                        <label for="name">Enter your Name</label>
                        <input type="text" name="name" id="name" class="form-control" placeholder=""
                            aria-describedby="helpId">
                    </div>
                    <div class="form-group">
                        <label for="name">Enter your Email</label>
                        <input type="email" name="email" id="email" class="form-control" placeholder=""
                            aria-describedby="helpId">
                    </div>

                    <div class="form-group">
                        <label for="">Enter your Message</label>
                        <textarea class="form-control" name="message" id="message" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <button type="button" class="btn
                                        btn-primary">Message</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/action.js"></script>
</body>

</html>