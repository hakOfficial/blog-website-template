<?php
include "left-sidebar.php"
?>
<div class="col-lg-9 col-md-12 col-sm-12">
    <div class="container">
        <div class="row">
            <div class="col-xl-9 col-md-12 col-sm-12">
                <div class="main_content">
                    <div class="custom_navbar">
                        <a href="" class="burger-btn" id="open"><button class="btn btn-primary"><i
                                    class="fas fa-bars"></i></button></a>
                    </div>
                    <div class="row mt-3">
                        <div class="col-xl-3 col-md-12 col-sm-12
                                        d-flex
                                        justify-content-center
                                        align-items-center mt-3">
                            <div class="blog_image">
                                <a href="single-post.php">
                                    <img src="images/h1-single-img-2.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-md-12 col-sm-12
                                        mt-5">
                            <a href="single-post.php" style="font-family: 'Oswald',
                                            sans-serif;">
                                <h3 class="px-4">
                                    A Loving Heart is the Truest
                                    Wisdom
                                </h3>
                            </a>
                            <p class="px-4">
                                Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at,Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at....
                            </p>
                            <p class="d-flex
                                            justify-content-around">
                                <span><i class="fas
                                                    fa-calendar-alt mr-2"></i>
                                    20
                                    June
                                    2021 </span>
                                <span> <i class="fa fa-folder mr-2" aria-hidden="true"></i>
                                    Javascript</span>
                                <span> <i class="fa fa-comments
                                                    mr-2" aria-hidden="true"></i> 27</span>
                            </p>
                        </div>
                        <div class="col-xl-3 col-md-12 col-sm-12
                                        d-flex
                                        justify-content-center
                                        align-items-center mt-3">
                            <div class="blog_image">
                                <a href="single-post.php">
                                    <img src="images/h1-single-img-2.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-md-12 col-sm-12
                                        mt-5">
                            <a href="single-post.php">
                                <h3 class="px-4">
                                    A Loving Heart is the Truest
                                    Wisdom
                                </h3>
                            </a>
                            <p class="px-4">
                                Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at,Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at....
                            </p>
                            <p class="d-flex
                                            justify-content-around">
                                <span><i class="fas
                                                    fa-calendar-alt mr-2"></i>
                                    20
                                    June
                                    2021 </span>
                                <span> <i class="fa fa-folder mr-2" aria-hidden="true"></i>
                                    Javascript</span>
                                <span> <i class="fa fa-comments
                                                    mr-2" aria-hidden="true"></i> 27</span>
                            </p>
                        </div>
                        <div class="col-xl-3 col-md-12 col-sm-12
                                        d-flex
                                        justify-content-center
                                        align-items-center mt-3">
                            <div class="blog_image">
                                <a href="single-post.php">
                                    <img src="images/h1-single-img-2.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-md-12 col-sm-12
                                        mt-5">
                            <a href="single-post.php">
                                <h3 class="px-4">
                                    A Loving Heart is the Truest
                                    Wisdom
                                </h3>
                            </a>
                            <p class="px-4">
                                Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at,Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at....
                            </p>
                            <p class="d-flex
                                            justify-content-around">
                                <span><i class="fas
                                                    fa-calendar-alt mr-2"></i>
                                    20
                                    June
                                    2021 </span>
                                <span> <i class="fa fa-folder mr-2" aria-hidden="true"></i>
                                    Javascript</span>
                                <span> <i class="fa fa-comments
                                                    mr-2" aria-hidden="true"></i> 27</span>
                            </p>
                        </div>
                        <div class="col-xl-3 col-md-12 col-sm-12
                                        d-flex
                                        justify-content-center
                                        align-items-center mt-3">
                            <div class="blog_image">
                                <a href="single-post.php">
                                    <img src="images/h1-single-img-2.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-md-12 col-sm-12
                                        mt-5">
                            <a href="single-post.php">
                                <h3 class="px-4">
                                    A Loving Heart is the Truest
                                    Wisdom
                                </h3>
                            </a>
                            <p class="px-4">
                                Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at,Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at....
                            </p>
                            <p class="d-flex
                                            justify-content-around">
                                <span><i class="fas
                                                    fa-calendar-alt mr-2"></i>
                                    20
                                    June
                                    2021 </span>
                                <span> <i class="fa fa-folder mr-2" aria-hidden="true"></i>
                                    Javascript</span>
                                <span> <i class="fa fa-comments
                                                    mr-2" aria-hidden="true"></i> 27</span>
                            </p>
                        </div>
                        <div class="col-xl-3 col-md-12 col-sm-12
                                        d-flex
                                        justify-content-center
                                        align-items-center mt-3">
                            <div class="blog_image">
                                <a href="single-post.php">
                                    <img src="images/h1-single-img-2.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-md-12 col-sm-12
                                        mt-5">
                            <a href="single-post.php">
                                <h3 class="px-4">
                                    A Loving Heart is the Truest
                                    Wisdom
                                </h3>
                            </a>
                            <p class="px-4">
                                Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at,Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at....
                            </p>
                            <p class="d-flex
                                            justify-content-around">
                                <span><i class="fas
                                                    fa-calendar-alt mr-2"></i>
                                    20
                                    June
                                    2021 </span>
                                <span> <i class="fa fa-folder mr-2" aria-hidden="true"></i>
                                    Javascript</span>
                                <span> <i class="fa fa-comments
                                                    mr-2" aria-hidden="true"></i> 27</span>
                            </p>
                        </div>
                        <div class="col-xl-3 col-md-12 col-sm-12
                                        d-flex
                                        justify-content-center
                                        align-items-center mt-3">
                            <div class="blog_image">
                                <a href="single-post.php">
                                    <img src="images/h1-single-img-2.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-md-12 col-sm-12
                                        mt-5">
                            <a href="single-post.php">
                                <h3 class="px-4">
                                    A Loving Heart is the Truest
                                    Wisdom
                                </h3>
                            </a>
                            <p class="px-4">
                                Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at,Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at....
                            </p>
                            <p class="d-flex
                                            justify-content-around">
                                <span><i class="fas
                                                    fa-calendar-alt mr-2"></i>
                                    20
                                    June
                                    2021 </span>
                                <span> <i class="fa fa-folder mr-2" aria-hidden="true"></i>
                                    Javascript</span>
                                <span> <i class="fa fa-comments
                                                    mr-2" aria-hidden="true"></i> 27</span>
                            </p>
                        </div>
                        <div class="col-xl-3 col-md-12 col-sm-12
                                        d-flex
                                        justify-content-center
                                        align-items-center mt-3">
                            <div class="blog_image">
                                <a href="single-post.php">
                                    <img src="images/h1-single-img-2.png" alt="">
                                </a>
                            </div>
                        </div>
                        <div class="col-xl-9 col-md-12 col-sm-12
                                        mt-5">
                            <a href="single-post.php">
                                <h3 class="px-4">
                                    A Loving Heart is the Truest
                                    Wisdom
                                </h3>
                            </a>
                            <p class="px-4">
                                Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at,Lorem ipsum, dolor sit amet
                                consectetur
                                adipisicing elit. Recusandae
                                pariatur
                                rem at....
                            </p>
                            <p class="d-flex
                                            justify-content-around">
                                <span><i class="fas
                                                    fa-calendar-alt mr-2"></i>
                                    20
                                    June
                                    2021 </span>
                                <span> <i class="fa fa-folder mr-2" aria-hidden="true"></i>
                                    Javascript</span>
                                <span> <i class="fa fa-comments
                                                    mr-2" aria-hidden="true"></i> 27</span>
                            </p>
                        </div>

                    </div>
                    <div class="pagination">
                        <a href="" class="paginate">1</a>
                        <a href="" class="paginate">2</a>
                        <a href="" class="paginate">3</a>
                    </div>
                </div>
            </div>
            <?php include "right-sidebar.php" ?>
        </div>
    </div>
</div>

</div>


<!-- jquery cdn -->
<script src="js/jquery.js"></script>
<!-- bootstrap cdn -->
<script src="js/bootstrap.min.js"></script>
<!-- custom js -->
<script src="js/action.js"></script>
</body>

</html>