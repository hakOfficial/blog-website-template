<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- font awsome cdn -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <!-- bootstrap cdn -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <!-- custom css  -->
    <link rel="stylesheet" href="css/style.css">
    <title>Blog Website</title>
</head>

<body>

    <div class="row">
        <div class="col-lg-3 col-md-0 col-sm-0">

            <div class="left_sidebar position-fixed">
                <a href="" class="close-btn btn btn-primary" id="close"><i class="fas fa-times"></i></a>
                <ul class="p-5">
                    <li><a href="index.php" class="nav-link active">Posts</a></li>
                    <li><a href="about.php" class="nav-link">About</a></li>
                    <li><a href="contact.php" class="nav-link">Contact</a></li>
                </ul>

                <div class="web_name">
                    <h2 class="text-center">Blog Website</h2>
                </div>
                <div class="subcribe p-5">
                    <div class="form-group">
                        <label for="">Subscribe for newslatter</label> <br>
                        <input type="text" class="form-control" placeholder="Subscribe">
                    </div>
                </div>
                <div class="footer p-3">
                    <h4 class="text-capitalize">
                        @copywrite powered by hilal ahmad
                    </h4>
                </div>
            </div>
        </div>